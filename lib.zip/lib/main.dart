import 'dart:math' as math;
import 'package:flutter/material.dart';

void main() {
  runApp(const CalculatorApp());
}

class CalculatorApp extends StatelessWidget {
  const CalculatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'KateCalc',
      theme: ThemeData(
        brightness: Brightness.dark,
        useMaterial3: true,
      ),
      home: const CalculatorScreen(),
    );
  }
}

class CalculatorScreen extends StatefulWidget {
  const CalculatorScreen({super.key});

  @override
  State<CalculatorScreen> createState() => _CalculatorScreenState();
}

class _CalculatorScreenState extends State<CalculatorScreen> {
  String display = '0';
  String expression = '';

  double? firstNumber;
  String? selectedOperator;

  bool startNewNumber = true;
  bool showingResult = false;

  // NUMBER
  void enterNumber(String number) {
    setState(() {
      if (showingResult) {
        expression = '';
        display = number;
        firstNumber = null;
        selectedOperator = null;
        showingResult = false;
        startNewNumber = false;
        return;
      }

      if (startNewNumber || display == '0') {
        display = number;
        startNewNumber = false;
      } else {
        display += number;
      }

      updateExpression();
    });
  }

  // DECIMAL
  void enterDecimal() {
    setState(() {
      if (showingResult) {
        expression = '';
        display = '0.';
        firstNumber = null;
        selectedOperator = null;
        showingResult = false;
        startNewNumber = false;
        return;
      }

      if (startNewNumber) {
        display = '0.';
        startNewNumber = false;
      } else if (!display.contains('.')) {
        display += '.';
      }

      updateExpression();
    });
  }

  // OPERATOR
  void selectOperator(String operator) {
    setState(() {
      double currentNumber = double.tryParse(display) ?? 0;

      // Agar operator already selected hai aur
      // doosra number abhi start nahi hua,
      // to sirf operator replace hoga.
      if (firstNumber != null &&
          selectedOperator != null &&
          startNewNumber) {
        selectedOperator = operator;
        updateExpression();
        return;
      }

      // Agar pehle se calculation chal rahi hai
      if (firstNumber != null &&
          selectedOperator != null &&
          !startNewNumber) {
        calculateInternal();
        currentNumber = double.tryParse(display) ?? 0;
      }

      firstNumber = currentNumber;
      selectedOperator = operator;
      startNewNumber = true;
      showingResult = false;

      updateExpression();
    });
  }

  // UPDATE EXPRESSION
  void updateExpression() {
    if (firstNumber != null && selectedOperator != null) {
      expression =
          '${formatNumber(firstNumber!)} $selectedOperator ${startNewNumber ? '' : display}';
    } else {
      expression = display;
    }
  }

  // CALCULATE
  void calculateInternal() {
    if (firstNumber == null || selectedOperator == null) {
      return;
    }

    double secondNumber = double.tryParse(display) ?? 0;
    double result = 0;

    switch (selectedOperator) {
      case '+':
        result = firstNumber! + secondNumber;
        break;

      case '-':
        result = firstNumber! - secondNumber;
        break;

      case '×':
        result = firstNumber! * secondNumber;
        break;

      case '÷':
        if (secondNumber == 0) {
          display = 'Error';
          firstNumber = null;
          selectedOperator = null;
          expression = '';
          startNewNumber = true;
          showingResult = true;
          return;
        }

        result = firstNumber! / secondNumber;
        break;

      // MODULUS
      case '%':
        if (secondNumber == 0) {
          display = 'Error';
          firstNumber = null;
          selectedOperator = null;
          expression = '';
          startNewNumber = true;
          showingResult = true;
          return;
        }

        result = firstNumber! % secondNumber;
        break;
    }

    display = formatNumber(result);
  }

  // EQUAL
  void calculate() {
    setState(() {
      if (firstNumber == null ||
          selectedOperator == null ||
          startNewNumber) {
        return;
      }

      String oldExpression =
          '${formatNumber(firstNumber!)} $selectedOperator $display';

      calculateInternal();

      expression = oldExpression;

      firstNumber = null;
      selectedOperator = null;
      startNewNumber = true;
      showingResult = true;
    });
  }

  // MODULUS
  void percentage() {
    setState(() {
      double currentNumber = double.tryParse(display) ?? 0;

      // Agar pehle koi operator nahi hai
      if (firstNumber == null || selectedOperator == null) {
        display = formatNumber(currentNumber);
        expression = display;
        startNewNumber = false;
        showingResult = false;
        return;
      }

      // Agar operator already hai aur current number enter ho chuka hai,
      // to % ko modulus operator ki tarah treat karo.
      if (!startNewNumber) {
        calculateInternal();

        expression =
            '${formatNumber(firstNumber!)} % ${formatNumber(currentNumber)}';

        firstNumber = null;
        selectedOperator = null;
        startNewNumber = true;
        showingResult = true;
        return;
      }

      // Agar current number abhi enter nahi hua,
      // to % operator select karo.
      selectedOperator = '%';
      startNewNumber = true;
      showingResult = false;

      updateExpression();
    });
  }

  // SQUARE ROOT
  void squareRoot() {
    setState(() {
      double number = double.tryParse(display) ?? 0;

      if (number < 0) {
        display = 'Error';
        expression = '';
        showingResult = true;
        startNewNumber = true;
        return;
      }

      display = formatNumber(math.sqrt(number));

      expression = '√$number';
      showingResult = true;
      startNewNumber = true;
    });
  }

  // DELETE
  void deleteLast() {
    setState(() {
      if (display == 'Error') {
        clearAll();
        return;
      }

      // --------------------------------------------------
      // CASE 1:
      // Current number ke digits delete karna
      //
      // 12 × 13
      //       ↓
      // 12 × 1
      //
      // 12 × 1
      //       ↓
      // 12 ×
      // --------------------------------------------------
      if (firstNumber != null &&
          selectedOperator != null &&
          !startNewNumber) {
        if (display.length > 1) {
          display = display.substring(0, display.length - 1);
          updateExpression();
          return;
        }

        // Last digit bhi delete ho gaya
        display = '0';
        startNewNumber = true;
        showingResult = false;

        updateExpression();
        return;
      }

      // --------------------------------------------------
      // CASE 2:
      // Operator delete karna
      //
      // 12 ×
      //  ↓
      // 12
      // --------------------------------------------------
      if (firstNumber != null &&
          selectedOperator != null &&
          startNewNumber) {
        selectedOperator = null;
        display = formatNumber(firstNumber!);
        firstNumber = null;

        startNewNumber = false;
        showingResult = false;

        expression = display;
        return;
      }

      // --------------------------------------------------
      // CASE 3:
      // Sirf number delete karna
      //
      // 12
      // ↓
      // 1
      // ↓
      // 0
      // --------------------------------------------------
      if (firstNumber == null && selectedOperator == null) {
        if (display.length > 1) {
          display = display.substring(0, display.length - 1);
        } else {
          display = '0';
          startNewNumber = true;
        }

        showingResult = false;
        expression = display;
        return;
      }

      // Safety reset
      display = '0';
      expression = '';
      firstNumber = null;
      selectedOperator = null;
      startNewNumber = true;
      showingResult = false;
    });
  }

  // CLEAR
  void clearAll() {
    setState(() {
      display = '0';
      expression = '';
      firstNumber = null;
      selectedOperator = null;
      startNewNumber = true;
      showingResult = false;
    });
  }

  // FORMAT
  String formatNumber(double number) {
    if (number.isNaN || number.isInfinite) {
      return 'Error';
    }

    if (number == number.toInt()) {
      return number.toInt().toString();
    }

    return number
        .toStringAsFixed(8)
        .replaceAll(RegExp(r'0+$'), '')
        .replaceAll(RegExp(r'\.$'), '');
  }

  // BUTTON
  Widget calculatorButton(
    String text, {
    required VoidCallback onPressed,
    bool special = false,
    bool operator = false,
    bool equal = false,
  }) {
    Color buttonColor;

    if (equal) {
      buttonColor = const Color(0xFF42A5F5);
    } else if (operator) {
      buttonColor = const Color(0xFF1565C0);
    } else if (special) {
      buttonColor = const Color(0xFF1976D2);
    } else {
      buttonColor = const Color(0xFF1E88E5);
    }

    return Expanded(
      child: Padding(
        padding: const EdgeInsets.all(5),
        child: ElevatedButton(
          onPressed: onPressed,
          style: ElevatedButton.styleFrom(
            backgroundColor: buttonColor,
            foregroundColor: Colors.white,
            elevation: 4,
            shadowColor: Colors.black54,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(18),
            ),
          ),
          child: Text(
            text,
            style: TextStyle(
              color: Colors.white,
              fontSize: equal ? 28 : 23,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D47A1),

      appBar: AppBar(
        backgroundColor: const Color(0xFF0D47A1),
        foregroundColor: Colors.white,
        centerTitle: true,
        elevation: 0,
        title: const Text(
          'KateCalc',
          style: TextStyle(
            color: Colors.white,
            fontSize: 22,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),

      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(12),

          child: Column(
            children: [

              // DISPLAY AREA
              Expanded(
                flex: 3,
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 15,
                  ),

                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [

                      // EXPRESSION
                      FittedBox(
                        fit: BoxFit.scaleDown,
                        alignment: Alignment.centerRight,
                        child: Text(
                          expression,
                          style: const TextStyle(
                            color: Colors.white70,
                            fontSize: 28,
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                      ),

                      const SizedBox(height: 8),

                      // RESULT
                      if (showingResult)
                        FittedBox(
                          fit: BoxFit.scaleDown,
                          alignment: Alignment.centerRight,
                          child: Text(
                            display,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 52,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ),

              // ROW 1
              Expanded(
                child: Row(
                  children: [
                    calculatorButton(
                      'AC',
                      special: true,
                      onPressed: clearAll,
                    ),
                    calculatorButton(
                      '⌫',
                      special: true,
                      onPressed: deleteLast,
                    ),
                    calculatorButton(
                      '%',
                      special: true,
                      onPressed: () => selectOperator('%'),
                    ),
                    calculatorButton(
                      '√',
                      special: true,
                      onPressed: squareRoot,
                    ),
                  ],
                ),
              ),

              // ROW 2
              Expanded(
                child: Row(
                  children: [
                    calculatorButton(
                      '7',
                      onPressed: () => enterNumber('7'),
                    ),
                    calculatorButton(
                      '8',
                      onPressed: () => enterNumber('8'),
                    ),
                    calculatorButton(
                      '9',
                      onPressed: () => enterNumber('9'),
                    ),
                    calculatorButton(
                      '÷',
                      operator: true,
                      onPressed: () => selectOperator('÷'),
                    ),
                  ],
                ),
              ),

              // ROW 3
              Expanded(
                child: Row(
                  children: [
                    calculatorButton(
                      '4',
                      onPressed: () => enterNumber('4'),
                    ),
                    calculatorButton(
                      '5',
                      onPressed: () => enterNumber('5'),
                    ),
                    calculatorButton(
                      '6',
                      onPressed: () => enterNumber('6'),
                    ),
                    calculatorButton(
                      '×',
                      operator: true,
                      onPressed: () => selectOperator('×'),
                    ),
                  ],
                ),
              ),

              // ROW 4
              Expanded(
                child: Row(
                  children: [
                    calculatorButton(
                      '1',
                      onPressed: () => enterNumber('1'),
                    ),
                    calculatorButton(
                      '2',
                      onPressed: () => enterNumber('2'),
                    ),
                    calculatorButton(
                      '3',
                      onPressed: () => enterNumber('3'),
                    ),
                    calculatorButton(
                      '-',
                      operator: true,
                      onPressed: () => selectOperator('-'),
                    ),
                  ],
                ),
              ),

              // ROW 5
              Expanded(
                child: Row(
                  children: [
                    calculatorButton(
                      '0',
                      onPressed: () => enterNumber('0'),
                    ),
                    calculatorButton(
                      '.',
                      onPressed: enterDecimal,
                    ),
                    calculatorButton(
                      '=',
                      equal: true,
                      onPressed: calculate,
                    ),
                    calculatorButton(
                      '+',
                      operator: true,
                      onPressed: () => selectOperator('+'),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}